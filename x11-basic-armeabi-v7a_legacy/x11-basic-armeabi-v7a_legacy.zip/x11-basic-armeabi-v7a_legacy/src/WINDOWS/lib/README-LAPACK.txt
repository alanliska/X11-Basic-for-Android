X11-Basic for WINDOWS was statically linked against the CLAPACK library.


LAPACK (Linear Algebra Package) is a standard software library for 
numerical linear algebra. 

LAPACK is licensed under a three-clause BSD style license, 
a permissive free software license with few restrictions.

For details see: http://www.netlib.org/lapack/
and
http://www.netlib.org/clapack/
