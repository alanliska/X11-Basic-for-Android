/* sfunctions.h String Funktionen  (c) Markus Hoffmann  */

/* This file is part of X11BASIC, the basic interpreter for Unix/X
 * ============================================================
 * X11BASIC is free software and comes with NO WARRANTY - read the file
 * COPYING for details
 */

/*Standard Funktionstyp */


int do_verify(STRING *,STRING *,STRING *, int);
